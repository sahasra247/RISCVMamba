`timescale 1ns / 1ps

module spe #(
    parameter DATA_WIDTH = 8,
    parameter SHIFT_VAL  = 6  // Rescaling shift: divide by 64 (Q2.6)
)(
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire signed [DATA_WIDTH-1:0] p_n,     // P_i
    input  wire signed [DATA_WIDTH-1:0] q_n,     // Q_i
    input  wire signed [DATA_WIDTH-1:0] p_next,  // P_{i+1}
    input  wire signed [DATA_WIDTH-1:0] q_next,  // Q_{i+1}
    output reg  signed [DATA_WIDTH-1:0] p_out,   // P_out = (P_{i+1} * P_i) >> SHIFT
    output reg  signed [DATA_WIDTH-1:0] q_out    // Q_out = (P_{i+1} * Q_i) >> SHIFT + Q_{i+1}
);

    wire signed [2*DATA_WIDTH-1:0] mult_pp;
    wire signed [2*DATA_WIDTH-1:0] mult_pq;
    wire signed [DATA_WIDTH-1:0]   mult_pq_scaled;
    wire signed [DATA_WIDTH:0]     add_res;

    // 2 Concurrent Multipliers
    assign mult_pp = p_next * p_n;
    assign mult_pq = p_next * q_n;

    // Rescaling shift (replaces floating point multiply)
    assign mult_pq_scaled = mult_pq >>> SHIFT_VAL;

    // 1 Adder
    assign add_res = mult_pq_scaled + q_next;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p_out <= 0;
            q_out <= 0;
        end else begin
            p_out <= mult_pp >>> SHIFT_VAL;
            q_out <= add_res[DATA_WIDTH-1:0];
        end
    end

endmodule