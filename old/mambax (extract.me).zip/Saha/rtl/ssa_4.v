`timescale 1ns / 1ps

// Four local inclusive prefixes, with exactly two registered stages.
// Grouping: t0, (t1 o t0), t2 o (t1 o t0), (t3 o t2) o (t1 o t0).
// All outputs belong to the same input batch. New batch per enabled cycle.
// Independent batches have zero incoming state; no cross-batch carry here.
module ssa_4 #(
    parameter integer DATA_WIDTH = 8,
    parameter integer SHIFT_VAL = 6
)(
    input  wire clk,
    input  wire rst_n,
    input  wire clk_en,
    input  wire in_valid,
    input  wire signed [DATA_WIDTH-1:0] p0, p1, p2, p3,
    input  wire signed [DATA_WIDTH-1:0] q0, q1, q2, q3,
    output wire out_valid,
    output wire signed [DATA_WIDTH-1:0] state0, state1, state2, state3,
    output wire signed [DATA_WIDTH-1:0] prefix_p0, prefix_p1, prefix_p2, prefix_p3
);
    wire signed [DATA_WIDTH-1:0] p_01, q_01, p_23, q_23;
    wire valid_01, valid_23;
    reg signed [DATA_WIDTH-1:0] p0_d1, q0_d1, p2_d1, q2_d1;
    reg signed [DATA_WIDTH-1:0] p0_d2, q0_d2, p01_d2, q01_d2;
    wire valid_0123;

    spe #(.DATA_WIDTH(DATA_WIDTH), .SHIFT_VAL(SHIFT_VAL)) u_spe01 (
        .clk(clk), .rst_n(rst_n), .clk_en(clk_en), .in_valid(in_valid),
        .p_n(p0), .q_n(q0), .p_next(p1), .q_next(q1),
        .p_out(p_01), .q_out(q_01), .out_valid(valid_01)
    );
    spe #(.DATA_WIDTH(DATA_WIDTH), .SHIFT_VAL(SHIFT_VAL)) u_spe23 (
        .clk(clk), .rst_n(rst_n), .clk_en(clk_en), .in_valid(in_valid),
        .p_n(p2), .q_n(q2), .p_next(p3), .q_next(q3),
        .p_out(p_23), .q_out(q_23), .out_valid(valid_23)
    );

    // Delay the direct paths by the same number of stages as the SPE paths.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p0_d1 <= 0;
            q0_d1 <= 0;
            p2_d1 <= 0;
            q2_d1 <= 0;
            p0_d2 <= 0;
            q0_d2 <= 0;
            p01_d2 <= 0;
            q01_d2 <= 0;
        end else if (clk_en) begin
            p0_d1 <= p0;
            q0_d1 <= q0;
            p2_d1 <= p2;
            q2_d1 <= q2;
            p0_d2 <= p0_d1;
            q0_d2 <= q0_d1;
            p01_d2 <= p_01;
            q01_d2 <= q_01;
        end
    end

    spe #(.DATA_WIDTH(DATA_WIDTH), .SHIFT_VAL(SHIFT_VAL)) u_spe_prop2 (
        .clk(clk), .rst_n(rst_n), .clk_en(clk_en), .in_valid(valid_01),
        .p_n(p_01), .q_n(q_01), .p_next(p2_d1), .q_next(q2_d1),
        .p_out(prefix_p2), .q_out(state2), .out_valid(out_valid)
    );
    spe #(.DATA_WIDTH(DATA_WIDTH), .SHIFT_VAL(SHIFT_VAL)) u_spe_prop3 (
        .clk(clk), .rst_n(rst_n), .clk_en(clk_en), .in_valid(valid_01 & valid_23),
        .p_n(p_01), .q_n(q_01), .p_next(p_23), .q_next(q_23),
        .p_out(prefix_p3), .q_out(state3), .out_valid(valid_0123)
    );

    assign prefix_p0 = p0_d2;
    assign prefix_p1 = p01_d2;
    assign state0 = q0_d2;
    assign state1 = q01_d2;
endmodule