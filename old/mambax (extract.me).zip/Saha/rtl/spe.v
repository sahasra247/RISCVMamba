`timescale 1ns / 1ps

// One registered tuple combine: later (p_next,q_next) o earlier (p_n,q_n).
// Arithmetic: full signed products; arithmetic floor shift; W-bit wrap.
// clk_en freezes data AND valid. Reset discards all in-flight work.
// A transaction advances only on a rising edge with clk_en=1.
module spe #(
    parameter integer DATA_WIDTH = 8,
    parameter integer SHIFT_VAL = 6
)(
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         clk_en,
    input  wire                         in_valid,
    input  wire signed [DATA_WIDTH-1:0]  p_n,
    input  wire signed [DATA_WIDTH-1:0]  q_n,
    input  wire signed [DATA_WIDTH-1:0]  p_next,
    input  wire signed [DATA_WIDTH-1:0]  q_next,
    output reg                          out_valid,
    output reg signed [DATA_WIDTH-1:0]   p_out,
    output reg signed [DATA_WIDTH-1:0]   q_out
);
    wire signed [2*DATA_WIDTH-1:0] mult_pp;
    wire signed [2*DATA_WIDTH-1:0] mult_pq;
    wire signed [2*DATA_WIDTH-1:0] shifted_pp;
    wire signed [2*DATA_WIDTH-1:0] shifted_pq;
    wire signed [DATA_WIDTH-1:0] mult_pq_scaled;
    wire signed [DATA_WIDTH:0] add_res;

    assign mult_pp = p_next * p_n;
    assign mult_pq = p_next * q_n;
    assign shifted_pp = mult_pp >>> SHIFT_VAL;
    assign shifted_pq = mult_pq >>> SHIFT_VAL;
    assign mult_pq_scaled = shifted_pq[DATA_WIDTH-1:0];
    // Explicit sign extension avoids dependence on expression sizing rules.
    assign add_res = $signed({mult_pq_scaled[DATA_WIDTH-1], mult_pq_scaled})
                   + $signed({q_next[DATA_WIDTH-1], q_next});

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_valid <= 1'b0;
            p_out <= 0;
            q_out <= 0;
        end else if (clk_en) begin
            out_valid <= in_valid;
            p_out <= shifted_pp[DATA_WIDTH-1:0];
            q_out <= add_res[DATA_WIDTH-1:0];
        end
    end
endmodule