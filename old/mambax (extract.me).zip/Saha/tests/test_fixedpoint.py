import random
import tempfile
import unittest
from pathlib import Path

from scanfuse.fixedpoint import DEFAULT, Format, combine, float_recurrence, packed_hex, sequential, ssa4
from scanfuse.vectors import generate


class FixedPointTests(unittest.TestCase):
    def test_wrap_not_saturate(self):
        self.assertEqual(combine((64, 50), (64, 100)), (64, -106))
        self.assertEqual(DEFAULT.wrap(-129), 127)

    def test_negative_shift_floors(self):
        self.assertEqual(combine((1, 0), (-1, -1)), (-1, -1))

    def test_input_quantization(self):
        self.assertEqual(DEFAULT.quantize(1, is_p=True), 64)
        self.assertEqual(DEFAULT.quantize(1, is_p=False), 32)
        self.assertEqual(DEFAULT.quantize(0.5 / 64, is_p=True), 0)
        self.assertEqual(DEFAULT.quantize(1.5 / 64, is_p=True), 2)
        self.assertEqual(DEFAULT.quantize(100, is_p=False), 127)
        with self.assertRaises(ValueError):
            DEFAULT.quantize(float("nan"), is_p=True)

    def test_tree_not_sequential(self):
        p, q = [63, 14, 39, 38], [-9, 5, -3, 2]
        self.assertEqual(sequential(p, q), [-9, 3, -2, 0])
        self.assertEqual([t[1] for t in ssa4(p, q)], [-9, 3, -2, 1])

    def test_identity_and_order(self):
        for p in range(-128, 128):
            for q in (-128, -1, 0, 1, 127):
                self.assertEqual(combine((64, 0), (p, q)), (p, q))
                self.assertEqual(combine((p, q), (64, 0)), (p, q))
        self.assertNotEqual(combine((32, 10), (16, 20)),
                            combine((16, 20), (32, 10)))

    def test_independent_modular_expression(self):
        rng = random.Random(47)
        for _ in range(10000):
            pi, qi, pj, qj = (rng.randint(-128, 127) for _ in range(4))
            raw_p = ((pj * pi) // 64) & 255
            raw_q = (((pj * qi) // 64) + qj) & 255
            expected = (raw_p if raw_p < 128 else raw_p - 256,
                        raw_q if raw_q < 128 else raw_q - 256)
            self.assertEqual(combine((pj, qj), (pi, qi)), expected)

    def test_nonzero_initial_and_float_reference(self):
        self.assertEqual(sequential([64, 64], [1, 2], initial=10), [11, 13])
        self.assertEqual(float_recurrence([0.5, 0.5], [1, 1], 2), [2, 2])

    def test_validation_and_packing(self):
        self.assertEqual(packed_hex([-128, -1, 0, 127]), "80ff007f")
        self.assertEqual(packed_hex([-1, 1], Format(5, 3, 2)), "3e1")
        with self.assertRaises(ValueError):
            ssa4([0], [0])
        with self.assertRaises(ValueError):
            combine((128, 0), (0, 0))
        with self.assertRaises(ValueError):
            Format(8, 7)

    def test_vectors_reproducible(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            first = generate(Path(a), random_cases=10, exhaustive_products=False)
            second = generate(Path(b), random_cases=10, exhaustive_products=False)
            self.assertEqual(first, second)
            for name in ("spe_vectors.hex", "ssa_vectors.hex", "manifest.json"):
                self.assertEqual((Path(a) / name).read_bytes(), (Path(b) / name).read_bytes())


if __name__ == "__main__":
    unittest.main()