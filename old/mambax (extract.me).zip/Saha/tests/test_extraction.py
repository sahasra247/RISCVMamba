"""Optional integration tests use a tiny RANDOM Mamba-1, never a download.

These validate the extraction algorithm, not accuracy of a trained checkpoint.
"""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HAS_DEPS = all(importlib.util.find_spec(m) is not None for m in ("torch", "transformers"))


@unittest.skipUnless(HAS_DEPS, "Optional torch/transformers dependencies not installed")
class ExtractionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import torch
        from transformers import MambaConfig, MambaForCausalLM
        torch.manual_seed(247)
        torch.set_num_threads(1)
        config = MambaConfig(vocab_size=32, hidden_size=8, state_size=4,
                             num_hidden_layers=2, expand=2, conv_kernel=4,
                             time_step_rank=2, use_cache=False)
        cls.model = MambaForCausalLM(config).float().eval()

    def test_real_block_path_and_tail_export(self):
        import torch
        from scanfuse.extract import extract_coefficients, export_trace
        from scanfuse.fixedpoint import DEFAULT, ssa4, packed_hex
        tokens = torch.tensor([[1, 4, 3, 2, 9, 8, 7]])
        result = extract_coefficients(self.model, tokens, layer_index=1)
        self.assertEqual(tuple(result["p"].shape), (1, 7, 16, 4))
        self.assertLess(result["metadata"]["actual_path_max_abs_error"], 1e-6)
        self.assertTrue(torch.all((result["p"] > 0) & (result["p"] <= 1)))
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            meta = export_trace(result, out)
            self.assertEqual(meta["sequence_length"], 7)
            self.assertEqual(meta["ssa_count"], 2)
            self.assertEqual(meta["valid_elements_last_block"], 3)
            tail_p = [DEFAULT.quantize(v, is_p=True) for v in result["p"][0, 4:, 0, 0].tolist()] + [64]
            tail_q = [DEFAULT.quantize(v, is_p=False) for v in result["q"][0, 4:, 0, 0].tolist()] + [0]
            expected = ssa4(tail_p, tail_q)
            self.assertEqual((out / "ssa_vectors.hex").read_text().splitlines()[1],
                             packed_hex(tail_p + tail_q + [t[0] for t in expected] +
                                        [t[1] for t in expected]))
            self.assertEqual(json.loads((out / "manifest.json").read_text()), meta)

    def test_normalization_is_not_skipped(self):
        import torch
        from scanfuse.extract import extract_coefficients
        tokens = torch.tensor([[1, 2, 3]])
        seen = []
        mixer = self.model.backbone.layers[0].mixer
        handle = mixer.register_forward_pre_hook(lambda _m, a: seen.append(a[0].detach().clone()))
        try:
            extract_coefficients(self.model, tokens)
        finally:
            handle.remove()
        embedding = self.model.backbone.embeddings(tokens)
        self.assertFalse(torch.allclose(seen[0], embedding))
        self.assertTrue(torch.allclose(seen[0], self.model.backbone.layers[0].norm(embedding)))

    def test_mask_and_training_restoration(self):
        import torch
        from scanfuse.extract import extract_coefficients
        self.model.train()
        try:
            result = extract_coefficients(self.model, torch.tensor([[1, 2, 0, 0]]),
                                          attention_mask=torch.tensor([[1, 1, 0, 0]]))
            self.assertTrue(self.model.training)
            self.assertTrue(torch.all(result["q"][:, 2:] == 0))
            self.assertLess(result["metadata"]["actual_path_max_abs_error"], 1e-6)
        finally:
            self.model.eval()

    def test_single_token_and_invalid_indices(self):
        import torch
        from scanfuse.extract import extract_coefficients, export_trace
        result = extract_coefficients(self.model, torch.tensor([[1]]))
        with tempfile.TemporaryDirectory() as temp:
            metadata = export_trace(result, Path(temp))
            self.assertEqual(metadata["valid_elements_last_block"], 1)
            with self.assertRaises(ValueError):
                export_trace(result, Path(temp), channel=1000)
        with self.assertRaises(ValueError):
            extract_coefficients(self.model, torch.tensor([[1]]), layer_index=-1)


if __name__ == "__main__":
    unittest.main()