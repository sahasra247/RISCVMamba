import importlib.util
import tempfile
from pathlib import Path
import unittest

HAS_DEPS = all(importlib.util.find_spec(m) is not None for m in ("torch", "transformers"))


@unittest.skipUnless(HAS_DEPS, "Optional extraction dependencies not installed")
class TraceExportTests(unittest.TestCase):
    def test_export_uses_tree_golden_not_serial(self):
        import torch
        from scanfuse.extract import export_trace
        result = {
            "p": torch.tensor([63, 14, 39, 38], dtype=torch.float32).reshape(1, 4, 1, 1) / 64,
            "q": torch.tensor([-9, 5, -3, 2], dtype=torch.float32).reshape(1, 4, 1, 1) / 32,
            "metadata": {"sequence_length": 4},
        }
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            meta = export_trace(result, output)
            self.assertEqual((output / "golden_state.hex").read_text().splitlines(),
                             ["f7", "03", "fe", "01"])
            self.assertEqual(meta["local_tree_vs_serial_mismatch_count"], 1)

    def test_export_reports_clipping_and_rejects_nonfinite(self):
        import torch
        from scanfuse.extract import export_trace
        result = {"p": torch.ones(1, 1, 1, 1), "q": torch.full((1, 1, 1, 1), 100.0),
                  "metadata": {}}
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            meta = export_trace(result, output)
            self.assertEqual(meta["q_input_clipped"], 1)
            self.assertEqual(meta["p_input_clipped"], 0)
            self.assertEqual(meta["sequence_length"], 1)
            result["q"].fill_(float("nan"))
            with self.assertRaises(ValueError):
                export_trace(result, output)


if __name__ == "__main__":
    unittest.main()