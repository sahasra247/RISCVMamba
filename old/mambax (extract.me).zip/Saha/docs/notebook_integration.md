# Using the corrected flow in the existing Kaggle notebook

The GitHub notebook is not a local workspace file, so it was not silently
rewritten. Keep your training/checkpoint cells. Replace the manual coefficient
extraction and golden-generation cells (original cells 16–20) with this flow.

## 1. Make the package importable

Copy the `scanfuse` directory into your Kaggle working directory, or add the
directory containing it to Python's import path. Install the pinned extraction
dependencies from [requirements-extraction.txt](../requirements-extraction.txt)
in the notebook environment. Restart the kernel after changing Transformers.

The extractor intentionally rejects other Transformers versions instead of
silently applying assumptions from a different implementation.

## 2. Load the saved model in FP32 and extract

```python
from pathlib import Path
import torch
from transformers import AutoTokenizer, MambaForCausalLM
from scanfuse.extract import extract_coefficients, export_trace

checkpoint = "/kaggle/working/my_mamba_model"
tokenizer = AutoTokenizer.from_pretrained(checkpoint)
reference_model = MambaForCausalLM.from_pretrained(
    checkpoint,
    torch_dtype=torch.float32,
).to("cuda" if torch.cuda.is_available() else "cpu").eval()

tokens = tokenizer(
    "What is machine learning?",
    return_tensors="pt",
    truncation=True,
    max_length=64,
).to(next(reference_model.parameters()).device)

result = extract_coefficients(
    reference_model,
    tokens["input_ids"],
    attention_mask=tokens.get("attention_mask"),
    layer_index=0,
)
result["metadata"]["model"] = checkpoint
manifest = export_trace(
    result,
    Path("/kaggle/working/scan_fuse_trace"),
    channel=0,
    state_index=0,
)
print(manifest)
```

This needs additional GPU memory if the training model/optimizer is still alive.
Use a fresh session or CPU execution if necessary; extraction does not need the
optimizer or another training run.

Do not directly pass embeddings to `in_proj`. The extractor captures the actual
mixer argument after block normalization, including for layers beyond layer 0.
It also validates the full mixer output against the reference implementation.

FP32 loading establishes a numerical reference. It does not claim to reproduce
the exact intermediate rounding of the former FP16/BF16 execution.

## 3. Run RTL on the exported trace

Download the entire `scan_fuse_trace` directory to the local workspace. Keep its
manifest together with both packed vector files. From the workspace root:

```sh
python3 -m scanfuse.verify --vectors scan_fuse_trace --build build/trained_trace
```

The simulator will check each exported local four-token block and each of its
SPE nodes against the new bit-exact oracle. It will also exercise stalls/bubbles
and reset behavior. A very short trace may not reach the periodic reset events;
the large synthetic stress suite provides that coverage.

Run additional channels, states, layers, and prompts into separate output
directories. A single channel/state is an initial check, not model-wide evidence.
Review clipping counts and state errors before deciding whether INT8 with these
fixed scales is adequate.

## Interpreting the files

- Full tensors preserve every extracted channel/state for later experiments.
- The packed RTL files select the lane specified by `channel`/`state_index`.
- Every block is a local prefix with zero incoming state, not a continuous scan.
- The four single-byte files are just the first block, padded if needed.
- The actual sequence length is recorded; `max_length=64` only sets an upper bound.
- The correct `golden_state` uses the **hardware tree order and wrap behavior**.
  Do not restore the old sequential, saturating golden-generation loop.

## Success criteria for milestones 1 and 2

1. Full mixer reconstruction passes at the documented FP32 tolerances.
2. Traces contain finite coefficients and report any input clipping.
3. SPE and SSA RTL match the bit-exact oracle on all valid outputs.
4. Synthetic stress tests pass for overflow, signed shifts, consecutive batches,
   bubbles, stalls, resets, and multiple parameter widths.
5. Numerical quality is reported separately from RTL correctness.

Only after these checks should the datapath become the basis for the custom
instruction's execution unit.