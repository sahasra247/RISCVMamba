# Scan-Fuse: correctness milestone

This workspace implements the first two milestones: **correct Mamba-1
coefficient extraction and bit-exact references**, and **repaired, stress-tested
SPE/SSA RTL**. The original papers are unchanged.

This is **not yet a RISC-V instruction implementation**, a complete Mamba-X
reproduction, or an end-to-end accuracy/performance result.

Observed test counts and limitations are recorded in
[the verification report](docs/verification_results.md).

## Files

| File | Purpose |
| --- | --- |
| [scanfuse/extract.py](scanfuse/extract.py) | Capture actual normalized mixer input, reconstruct and validate its output, export traces |
| [scanfuse/fixedpoint.py](scanfuse/fixedpoint.py) | Explicit arithmetic contract; SPE, four-prefix tree, serial and floating references |
| [scanfuse/vectors.py](scanfuse/vectors.py) | Deterministic directed/random/exhaustive-product test generation |
| [rtl/spe.v](rtl/spe.v) | One-stage tuple-combine datapath |
| [rtl/ssa_4.v](rtl/ssa_4.v) | Two-stage, batch-aligned four-prefix network |
| [tb/tb_spe.sv](tb/tb_spe.sv) | Signed arithmetic, valid, reset, and stall checks |
| [tb/tb_ssa_4.sv](tb/tb_ssa_4.sv) | Cycle-by-cycle scoreboard for all four P and Q outputs |
| [scanfuse/verify.py](scanfuse/verify.py) | Generate vectors, compile, simulate, and save results |
| [scanfuse/demo.py](scanfuse/demo.py) | Offline tiny untrained model → extraction → RTL smoke test |
| [docs/notebook_integration.md](docs/notebook_integration.md) | Replace the notebook's extraction/export cells |

## 1. Run arithmetic and RTL tests

Run commands from this workspace directory. The fixed-point tests and RTL runner
use only Python's standard library. Icarus Verilog (`iverilog` and `vvp`) is needed
for RTL simulation.

```sh
python3 -m unittest discover -s tests -v
python3 -m scanfuse.verify --parameter-sweep
```

Without optional model dependencies, extraction tests are explicitly **skipped**,
not reported as passed. `--parameter-sweep` tests W=8/S=6, W=5/S=3 and W=16/S=10.
The last format is **fixed-point INT16, not FP16**.

The runner finds tools on PATH or via `IVERILOG`, `VVP`, and optional
`IVERILOG_BASE`. It also detects the user-local installation under
`~/tools/iverilog/usr/`, installed during this implementation without sudo.

Outputs are generated under `build/`: packed vectors, a vector manifest,
compiled simulations, and `rtl_results.json`. Failures return a nonzero exit code.

Default INT8 coverage with seed 247:

- 4,096 directed edge combinations.
- 65,536 signed multiplier input pairs, exercised in **both** multipliers.
- 2,000 additional random SPE cases: **71,632 SPE checks total**.
- 2,007 four-tuple blocks, checking all four prefix products and states.
- SSA pass 0: consecutive new batches, no bubbles/stalls.
- SSA pass 1: bubbles and multi-cycle stalls; all batches checked.
- SSA pass 2: reset during traffic; only in-flight work is deliberately canceled.
- Asynchronous reset is checked away from rising edges; held outputs and valid
  bits must not change during a stall.

This does **not** exhaust the 2^32 possible four-operand SPE inputs. The product
pair sweep is exhaustive; the full operation is tested with directed/random
coverage. Timing is functional simulation, not synthesis timing closure.

## 2. Run coefficient-extraction tests

Use Python 3.12 with the optional dependencies. A compatible CPU-only PyTorch
build is sufficient; `mamba-ssm`, `causal-conv1d`, a GPU, and a downloaded model
are **not** required for the offline tests.

```sh
python -m pip install -r requirements-extraction.txt
python -m unittest discover -s tests -v
python -m scanfuse.demo
```

In this WSL session an isolated environment is already available. These commands
run every Python test and the complete model-to-RTL smoke test:

```sh
~/tools/scanfuse-py312/bin/python -m unittest discover -s tests -v
~/tools/scanfuse-py312/bin/python -m scanfuse.demo
```

The offline model is **random and untrained**. Its widened synthetic weights
exercise nonzero quantized Q values. These tests validate the extraction path
and file/simulator integration, not a trained model's accuracy.

## 3. Extract YOUR trained checkpoint

Use the Hugging Face **Mamba-1** checkpoint produced by your notebook. The
extractor is deliberately pinned to `transformers==4.46.3` and FP32 reference
execution. It does not support Mamba-2 or cached decoding yet.

```sh
python -m scanfuse.extract --model /path/to/my_mamba_model \
  --prompt "What is machine learning?" --max-length 64 \
  --layer 0 --channel 0 --state 0 --device cpu \
  --output artifacts/model_trace
python -m scanfuse.verify --vectors artifacts/model_trace --build build/model_trace
```

Use `--device cuda` on your GPU machine. If tokenizer files were not saved with
the checkpoint, specify `--tokenizer state-spaces/mamba-130m-hf` (or its local
tokenizer directory). No remote custom code is enabled.

**The real checkpoint is not present in this workspace.** It has not been tested
here. The model ID/path and layer are recorded in the output manifest when using
the command-line extractor.

### What extraction now does correctly

1. Runs the actual backbone with `use_cache=False`, in eval mode.
2. Hooks the chosen mixer's input **after residual/block normalization**.
3. Reproduces input projection, causal convolution, activation and attention
   masking, selection projections, and softplus (including the dt bias once).
4. Computes P = exp(dt A) and Q = (dt B) x in FP32, matching the pinned HF path.
5. Reconstructs the full mixer output: recurrence, C projection, D skip, gate,
   and output projection. Asserts closeness to both `slow_forward` and the actual
   captured mixer output. A failed check prevents export.
6. Records the **actual** token count, rather than claiming 64 for a shorter prompt.

### Exported artifacts

- `coefficients.pt`: all extracted P/Q tensors in [batch,time,channel,state] order.
- `manifest.json`: model/layer, shape, numeric format, clipping counts,
  reconstruction errors, quantized-state errors, true length, and tail validity.
- `spe_vectors.hex`: packed individual combines from every selected-lane block.
- `ssa_vectors.hex`: packed inputs and tree-matched expected outputs.
- `inputs_P.hex`, `inputs_Q.hex`, `golden_state.hex`, `golden_prefix_P.hex`:
  convenient single-byte files for the **first four-token block**.

Every SSA record is an **independent local prefix** starting from zero incoming
state. The final partial block is padded with identity tuples (P=64, Q=0).
The real prefix length is retained in the manifest. These records do not pretend
to implement a continuous global scan across blocks.

## Arithmetic contract

| Boundary | Rule |
| --- | --- |
| Input P | Signed 8-bit, six fractional bits; represent real P as integer / 64 |
| Input Q and state | Signed 8-bit, five fractional bits; real Q/state = integer / 32 |
| Float → input integers | Round nearest, ties-to-even; clip to [-128,127] |
| Multiplication | Full signed 16-bit result |
| Product rescaling | Arithmetic right shift by 6; negative values round toward negative infinity |
| Internal narrowing/addition | Two's-complement wrap; **no saturation** |

For later tuple j and earlier tuple i:

```text
Pout = wrap8((Pj * Pi) >> 6)
Qout = wrap8(wrap8((Pj * Qi) >> 6) + Qj)
```

The different P and Q scales are intentional: multiplying by P introduces a
factor of 64, so **both products shift by six**, not by the Q fractional width.
The representable real ranges are P in [-2, 1.984375] and Q/state in [-4, 3.96875].

Input clipping and internal wrap are separate, explicitly specified decisions.
If saturation or guard bits are added later, update both the reference and RTL;
do not simply change the Python golden model.

This fixed-global-scale scheme is a prototype, **not Mamba-X's full calibrated
quantization scheme**. Quantization quality must be assessed on real traces.

## Why there are different references

`ssa4()` is the **bit-exact RTL oracle**. It uses the exact grouping:

```text
t01 = combine(t1, t0)
t23 = combine(t3, t2)
prefixes = [t0, t01, combine(t2, t01), combine(t23, t01)]
```

`sequential()` is a fixed-point serial recurrence, used for comparison only.
`float_recurrence()` measures numerical error over the original coefficients.

For P=[63,14,39,38], Q=[-9,5,-3,2], the serial states are [-9,3,-2,0],
but the correct hardware tree states are [-9,3,-2,1]. Rounding makes the
quantized combine non-associative. This is a permanent regression test.

The manifest's state errors are numerical diagnostics, not pass/fail thresholds
or end-to-end language-model accuracy. A passing RTL test only means **the RTL
matches its defined integer arithmetic**.

## RTL interface and timing

Both modules now require `clk_en` and `in_valid` and expose `out_valid`.
Do not leave these new ports unconnected in an existing Vivado project.

- `rst_n=0`: asynchronously clears data and valid, discarding in-flight work.
- `clk_en=0`: freezes **all** stages and valid bits. Inputs may change but are ignored.
- `clk_en=1, in_valid=0`: advances a bubble; previously accepted work still advances.
- `clk_en=1, in_valid=1`: accepts one new tuple pair / four-tuple batch.
- Data is meaningful only when `out_valid=1`. During a stall, the same valid
  output is held; a consumer sharing this enable must not count it repeatedly.

This is a **shared-enable pipeline**, not an elastic ready/valid interface.
There is no independent downstream backpressure. Stall the entire pipeline and
its consumer together using `clk_en`.

| Event (no stalls) | SPE | SSA |
| --- | --- | --- |
| Rising edge k accepts batch A | A's output appears after edge k | First stage captures A |
| Rising edge k+1 accepts batch B | B's output appears after edge k+1 | All four A prefixes appear after edge k+1 |
| Rising edge k+2 | Next combine | All four B prefixes appear |

Thus SPE has **one registered stage**, SSA has **two registered stages**, and both
accept new work every enabled cycle. Testbenches sample after nonblocking updates
to avoid races. Each disabled edge adds wall-clock latency but does not advance
the pipeline.

`prefix_p0..prefix_p3` are exposed alongside `state0..state3`. They preserve the
prefix products needed for a later chunk-carry stage. Applying a nonzero incoming
state and defining its quantization are separate future steps, not silently
handled by this module.

## Vivado simulation

Add the two RTL sources and the desired SystemVerilog testbench, set
`tb_spe` or `tb_ssa_4` as simulation top, and set the runtime to run until finish.
Provide simulation plusargs `+VECTORS=/absolute/path/to/the/packed/file.hex`
and `+COUNT=<matching count from manifest.json>`. For nondefault formats, set the
testbench's `DATA_WIDTH` and `SHIFT_VAL` parameters to match the manifest.
No Windows drive path is hard-coded in the new tests.

The Python runner automates these steps for Icarus. A Vivado installation was not
available for validation here.

## Deliberately deferred

- RISC-V decode, operand staging, register-file access, and writeback.
- Nonzero incoming state and cross-block carry hardware.
- Saturation/guard-bit design-space exploration and calibrated quantization.
- FMA/FP16 numerical semantics, ISA equivalence, and throughput comparisons.
- Trained-checkpoint and end-to-end task-accuracy evaluation.