"""Generate vectors, compile RTL, run self-checking simulations, record results."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess

from .fixedpoint import Format
from .vectors import generate

ROOT = Path(__file__).resolve().parents[1]


def executable(name: str, env_name: str) -> str:
    candidate = os.environ.get(env_name) or shutil.which(name)
    if candidate:
        return candidate
    # This workspace's WSL environment has no sudo; support the user-local
    # simulator as a fallback, without hard-coding the user's account name.
    local = Path.home() / "tools/iverilog/usr/bin" / name
    if local.is_file():
        return str(local)
    raise RuntimeError(f"{name} not found; install Icarus Verilog or set {env_name}")


def simulate(vectors: Path, build: Path) -> list[dict]:
    metadata = json.loads((vectors / "manifest.json").read_text())
    fmt = Format(metadata["width"], metadata["shift"], metadata["q_fraction"])
    ivl = executable("iverilog", "IVERILOG")
    vvp = executable("vvp", "VVP")
    support = os.environ.get("IVERILOG_BASE")
    if not support:
        # Detect support files for a relocatable .deb extraction.
        prefix = Path(ivl).resolve().parent.parent
        options = list((prefix / "lib").glob("*/ivl")) + [prefix / "lib/ivl"]
        support = next((str(p) for p in options if (p / "ivl").is_file()), None)
    build.mkdir(parents=True, exist_ok=True)
    results = []
    for module, key in (("spe", "spe_count"), ("ssa_4", "ssa_count")):
        count = metadata[key]
        if not 1 <= count <= 200000:
            raise ValueError("Testbench supports 1..200000 records")
        top = "tb_" + module
        image = build / (top + ".vvp")
        command = [ivl]
        if support:
            command += ["-B", support]
        command += ["-g2012", "-Wall", "-s", top,
                    f"-P{top}.DATA_WIDTH={fmt.width}", f"-P{top}.SHIFT_VAL={fmt.shift}",
                    "-o", str(image), str(ROOT / "rtl/spe.v"),
                    str(ROOT / "rtl/ssa_4.v"), str(ROOT / "tb" / (top + ".sv"))]
        compiled = subprocess.run(command, text=True, capture_output=True, check=True)
        vector_file = vectors / ("spe_vectors.hex" if module == "spe" else "ssa_vectors.hex")
        result = subprocess.run([vvp, str(image), f"+VECTORS={vector_file}",
                                 f"+COUNT={count}"], text=True, capture_output=True, check=True)
        if "PASS " not in result.stdout:
            raise RuntimeError("Simulator returned without a PASS marker")
        print(result.stdout, end="")
        if compiled.stderr:
            print(compiled.stderr, end="")
        results.append({"module": module, "width": fmt.width, "shift": fmt.shift,
                        "vector_count": count, "stdout": result.stdout,
                        "compile_stderr": compiled.stderr, "stderr": result.stderr})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--vectors", type=Path, help="Use an existing trace directory instead of random vectors")
    parser.add_argument("--build", type=Path, default=ROOT / "build")
    parser.add_argument("--seed", type=int, default=247)
    parser.add_argument("--random-cases", type=int, default=2000)
    parser.add_argument("--parameter-sweep", action="store_true", help="Also test W=5/S=3 and W=16/S=10")
    args = parser.parse_args()
    if args.parameter_sweep and args.vectors:
        parser.error("--parameter-sweep cannot be used with --vectors")
    build = args.build.resolve()
    results = []
    formats = [Format()]
    if args.parameter_sweep:
        formats += [Format(5, 3, 2), Format(16, 10, 9)]
    for fmt in formats:
        label = f"w{fmt.width}_s{fmt.shift}"
        vectors = args.vectors.resolve() if args.vectors else build / "vectors" / label
        if not args.vectors:
            generate(vectors, seed=args.seed, random_cases=args.random_cases,
                     exhaustive_products=fmt.width <= 8, fmt=fmt)
        try:
            results.extend(simulate(vectors, build / "sim" / label))
        except subprocess.CalledProcessError as error:
            print(error.stdout or "")
            print(error.stderr or "")
            raise SystemExit(f"Compilation/simulation failed with exit code {error.returncode}") from error
    report = build / "rtl_results.json"
    report.write_text(json.dumps(results, indent=2) + "\n")
    print(f"Results: {report}")


if __name__ == "__main__":
    main()