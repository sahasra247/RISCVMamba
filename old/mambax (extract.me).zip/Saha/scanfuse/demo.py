"""Offline smoke test: random tiny Mamba -> coefficient export -> actual RTL.

This deliberately uses an UNTRAINED model. It validates the toolchain, not
trained-model numerical quality, downstream accuracy, or performance.
"""

import argparse
from pathlib import Path

import torch
from transformers import MambaConfig, MambaForCausalLM

from .extract import export_trace, extract_coefficients
from .verify import simulate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("build/demo"))
    args = parser.parse_args()
    torch.manual_seed(247)
    torch.set_num_threads(1)
    model = MambaForCausalLM(MambaConfig(
        vocab_size=32, hidden_size=8, state_size=4, num_hidden_layers=2,
        expand=2, conv_kernel=4, time_step_rank=2, use_cache=False,
    )).float().eval()
    # Widen synthetic activations so this smoke test also exports nonzero Q.
    # These changes are NOT training and must never be used as accuracy evidence.
    with torch.no_grad():
        for layer in model.backbone.layers:
            mixer = layer.mixer
            mixer.in_proj.weight.uniform_(-0.5, 0.5)
            mixer.x_proj.weight.uniform_(-0.5, 0.5)
            mixer.dt_proj.weight.zero_()
            mixer.dt_proj.bias.fill_(0.5)
    tokens = torch.randint(0, 32, (1, 19))
    result = extract_coefficients(model, tokens, layer_index=1)
    result["metadata"]["model"] = "UNTRAINED synthetic tiny Mamba; widened random weights"
    # Select the lane with the largest |Q| so its fixed-point trace is meaningful.
    lane = int(result["q"][0].abs().amax(dim=0).argmax())
    channel, state = divmod(lane, model.config.state_size)
    output = args.output.resolve()
    metadata = export_trace(result, output, channel=channel, state_index=state)
    print("UNTRAINED model smoke test; not model-accuracy evidence")
    print(f"Actual tokens: {metadata['sequence_length']}; blocks: {metadata['ssa_count']}; "
          f"real elements in final block: {metadata['valid_elements_last_block']}")
    print(f"Full mixer max absolute reconstruction error: {metadata['actual_path_max_abs_error']}")
    simulate(output, output / "sim")


if __name__ == "__main__":
    main()