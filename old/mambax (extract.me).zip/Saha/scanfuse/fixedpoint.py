"""The integer contract shared by Python and RTL (no third-party dependencies).

P has `shift` fractional bits; Q/state has `q_fraction` fractional bits.
Input conversion rounds to nearest, ties to even, and clips. INTERNAL arithmetic
instead wraps modulo 2**width after an arithmetic right shift (floor, not round).
These are deliberately different policies at two different boundaries.
"""

from dataclasses import dataclass
import math
from typing import Sequence

TuplePQ = tuple[int, int]


@dataclass(frozen=True)
class Format:
    width: int = 8
    shift: int = 6
    q_fraction: int = 5

    def __post_init__(self):
        if self.width < 2:
            raise ValueError("width must be at least 2")
        if not 0 <= self.shift < self.width - 1:
            raise ValueError("shift must allow +1.0 to be represented in signed P")
        if not 0 <= self.q_fraction < self.width:
            raise ValueError("invalid Q fractional-bit count")

    @property
    def minimum(self) -> int:
        return -(1 << (self.width - 1))

    @property
    def maximum(self) -> int:
        return (1 << (self.width - 1)) - 1

    def wrap(self, value: int) -> int:
        return (int(value) - self.minimum) % (1 << self.width) + self.minimum

    def quantize(self, value: float, *, is_p: bool) -> int:
        if not math.isfinite(value):
            raise ValueError("cannot quantize a non-finite value")
        scale = 1 << (self.shift if is_p else self.q_fraction)
        return min(self.maximum, max(self.minimum, round(value * scale)))


DEFAULT = Format()


def combine(later: TuplePQ, earlier: TuplePQ, fmt: Format = DEFAULT) -> TuplePQ:
    """One SPE. Order matters: the later tuple is the left operand.

    All inputs are signed W-bit integers. Python integers model the full 2W-bit
    signed products exactly. Match RTL's narrowing before the Q addition.
    """
    pj, qj = later
    pi, qi = earlier
    if any(not fmt.minimum <= v <= fmt.maximum for v in (pj, qj, pi, qi)):
        raise ValueError("tuple input outside signed format range")
    pp = fmt.wrap((pj * pi) >> fmt.shift)
    pq = fmt.wrap((pj * qi) >> fmt.shift)
    return pp, fmt.wrap(pq + qj)


def ssa4(p: Sequence[int], q: Sequence[int], fmt: Format = DEFAULT) -> list[TuplePQ]:
    """Exact grouping implemented by ssa_4, NOT Hillis-Steele or a serial fold."""
    if len(p) != 4 or len(q) != 4:
        raise ValueError("ssa4 requires exactly four P and four Q inputs")
    if any(not fmt.minimum <= v <= fmt.maximum for v in (*p, *q)):
        raise ValueError("SSA input outside signed format range")
    t = list(zip(p, q))
    t01 = combine(t[1], t[0], fmt)
    t23 = combine(t[3], t[2], fmt)
    return [t[0], t01, combine(t[2], t01, fmt), combine(t23, t01, fmt)]


def sequential(p: Sequence[int], q: Sequence[int], fmt: Format = DEFAULT,
               initial: int = 0) -> list[int]:
    """Quantized serial recurrence: useful comparison, not a tree RTL oracle."""
    if len(p) != len(q):
        raise ValueError("P and Q lengths differ")
    if not fmt.minimum <= initial <= fmt.maximum:
        raise ValueError("initial state outside signed format range")
    h = initial
    result = []
    for pi, qi in zip(p, q):
        _, h = combine((pi, qi), (0, h), fmt)
        result.append(h)
    return result


def float_recurrence(p: Sequence[float], q: Sequence[float],
                     initial: float = 0.0) -> list[float]:
    """Python float reference for numerical error, not bit-exact RTL checking."""
    if len(p) != len(q):
        raise ValueError("P and Q lengths differ")
    h = initial
    result = []
    for pi, qi in zip(p, q):
        h = pi * h + qi
        result.append(h)
    return result


def packed_hex(values: Sequence[int], fmt: Format = DEFAULT) -> str:
    """Pack values MSB first, with no padding between non-byte-width elements."""
    packed = 0
    for value in values:
        if not fmt.minimum <= value <= fmt.maximum:
            raise ValueError("packed value outside signed format range")
        packed = (packed << fmt.width) | (value & ((1 << fmt.width) - 1))
    return f"{packed:0{(len(values) * fmt.width + 3) // 4}x}"