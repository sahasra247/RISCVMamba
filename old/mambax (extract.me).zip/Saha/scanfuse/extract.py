"""Extract and validate Mamba-1 tuples from the ACTUAL normalized mixer input.

Supported reference: transformers==4.46.3 MambaForCausalLM, FP32, no cache.
No training, CUDA extensions, or downloaded checkpoint is needed for unit tests.
Run this module on the machine containing your trained checkpoint for real traces.
"""

import argparse
import json
import math
from pathlib import Path

import torch
import torch.nn.functional as F
import transformers
from transformers import AutoTokenizer, MambaForCausalLM

from .fixedpoint import DEFAULT, combine, float_recurrence, packed_hex, sequential, ssa4


@torch.no_grad()
def extract_coefficients(model, input_ids, *, layer_index=0, attention_mask=None,
                         atol=1e-4, rtol=1e-4):
    """Return CPU tensors P,Q [batch,time,channel,state] and validation metadata.

    The hook captures the argument AFTER the block's residual/norm path. We run
    the real backbone with use_cache=False; no embedding-to-mixer shortcut.
    Reconstructing the full mixer output (C projection, D skip, gate, out_proj)
    provides an independent check against both slow_forward and the actual path.
    FP32 is intentional: quantization error is evaluated separately after export.
    """
    if transformers.__version__ != "4.46.3":
        raise RuntimeError("Extraction is validated for transformers==4.46.3 only")
    if not isinstance(model, MambaForCausalLM):
        raise TypeError("Expected Hugging Face MambaForCausalLM (Mamba-1)")
    if not 0 <= layer_index < len(model.backbone.layers):
        raise ValueError("layer_index out of range")
    if input_ids.ndim != 2 or input_ids.shape[1] == 0:
        raise ValueError("input_ids must be nonempty [batch, time]")
    mixer = model.backbone.layers[layer_index].mixer
    if mixer.in_proj.weight.dtype != torch.float32:
        raise ValueError("Load the checkpoint with torch_dtype=torch.float32")
    if attention_mask is not None:
        if attention_mask.shape != input_ids.shape:
            raise ValueError("attention_mask shape must match input_ids")
        if not torch.all((attention_mask == 0) | (attention_mask == 1)):
            raise ValueError("attention_mask must be binary")

    captured = {}

    def before(_module, args, kwargs):
        captured["input"] = args[0].detach().clone()
        mask = kwargs.get("attention_mask")
        captured["mask"] = None if mask is None else mask.detach().clone()

    def after(_module, _args, output):
        captured["actual"] = output.detach().clone()

    was_training = model.training
    model.eval()
    pre = mixer.register_forward_pre_hook(before, with_kwargs=True)
    post = mixer.register_forward_hook(after)
    try:
        model.backbone(input_ids=input_ids, attention_mask=attention_mask,
                       use_cache=False, return_dict=True)
    finally:
        pre.remove()
        post.remove()
        model.train(was_training)

    normalized = captured["input"]
    mask = captured["mask"]
    batch, length, _ = normalized.shape
    projected = mixer.in_proj(normalized).transpose(1, 2)
    x, gate = projected.chunk(2, dim=1)
    if mask is not None:
        x = x * mask.unsqueeze(1)
    x = mixer.act(mixer.conv1d(x)[..., :length])
    if mask is not None:
        x = x * mask.unsqueeze(1)

    selected = mixer.x_proj(x.transpose(1, 2))
    dt, b, c = torch.split(selected, [mixer.time_step_rank,
                                     mixer.ssm_state_size,
                                     mixer.ssm_state_size], dim=-1)
    # dt_proj includes its bias. Applying that bias a second time is incorrect.
    dt = F.softplus(mixer.dt_proj(dt)).transpose(1, 2)
    a = -torch.exp(mixer.A_log.float())
    p = torch.exp(a[None, :, None, :] * dt[:, :, :, None])
    q = (dt[:, :, :, None] * b[:, None, :, :].float()) * x[:, :, :, None].float()

    h = torch.zeros((batch, mixer.intermediate_size, mixer.ssm_state_size),
                    device=x.device, dtype=normalized.dtype)
    outputs = []
    for t in range(length):
        h = p[:, :, t, :] * h + q[:, :, t, :]
        outputs.append(torch.matmul(h.to(normalized.dtype),
                                    c[:, t, :].unsqueeze(-1))[:, :, 0])
    y = torch.stack(outputs, dim=-1)
    y = (y + x * mixer.D[None, :, None]) * mixer.act(gate)
    reconstructed = mixer.out_proj(y.transpose(1, 2))

    # Explicitly use eval for the reference even when the caller was training.
    was_mixer_training = mixer.training
    mixer.eval()
    try:
        slow = mixer.slow_forward(normalized, cache_params=None, attention_mask=mask)
    finally:
        mixer.train(was_mixer_training)
    torch.testing.assert_close(reconstructed, slow, atol=atol, rtol=rtol)
    torch.testing.assert_close(reconstructed, captured["actual"], atol=atol, rtol=rtol)
    if not torch.isfinite(p).all() or not torch.isfinite(q).all():
        raise ValueError("Non-finite extracted coefficients")

    return {
        "p": p.permute(0, 2, 1, 3).contiguous().cpu(),
        "q": q.permute(0, 2, 1, 3).contiguous().cpu(),
        "metadata": {
            "transformers": transformers.__version__, "torch": str(torch.__version__),
            "layer_index": layer_index, "sequence_length": length,
            "shape_order": "batch,time,channel,state", "dtype": "float32",
            "initial_state": 0, "use_cache": False,
            "captured_after_block_normalization": True,
            "slow_path_max_abs_error": float((reconstructed - slow).abs().max()),
            "actual_path_max_abs_error": float((reconstructed - captured["actual"]).abs().max()),
            "validation_atol": atol, "validation_rtol": rtol,
        },
    }


def export_trace(result, output: Path, *, batch_index=0, channel=0, state_index=0):
    """Export a selected lane for RTL and keep full FP32 tensors for analysis.

    Each four-timestep RTL record is an INDEPENDENT local-prefix calculation.
    It is NOT a continuous global scan. Final incomplete blocks are identity-
    padded; the manifest retains the true sequence length and valid tail count.
    """
    p, q = result["p"], result["q"]
    if p.shape != q.shape or p.ndim != 4 or p.shape[1] == 0:
        raise ValueError("Expected matching nonempty [batch,time,channel,state] tensors")
    for index, size in ((batch_index, p.shape[0]), (channel, p.shape[2]),
                        (state_index, p.shape[3])):
        if not 0 <= index < size:
            raise ValueError("Selected trace index out of range")
    raw_p = p[batch_index, :, channel, state_index].tolist()
    raw_q = q[batch_index, :, channel, state_index].tolist()
    fp = [DEFAULT.quantize(v, is_p=True) for v in raw_p]
    fq = [DEFAULT.quantize(v, is_p=False) for v in raw_q]
    output.mkdir(parents=True, exist_ok=True)
    records, spe_records, local_errors, topology_differences = [], [], [], []
    first = None
    for start in range(0, len(fp), 4):
        valid = min(4, len(fp) - start)
        bp = fp[start:start + 4] + [64] * (4 - valid)
        bq = fq[start:start + 4] + [0] * (4 - valid)
        expected = ssa4(bp, bq)
        ep, eq = [t[0] for t in expected], [t[1] for t in expected]
        records.append(packed_hex(bp + bq + ep + eq))
        # Exercise exactly the four SPE nodes used by this block.
        tuples = list(zip(bp, bq))
        t01, t23 = combine(tuples[1], tuples[0]), combine(tuples[3], tuples[2])
        for earlier, later in ((tuples[0], tuples[1]), (tuples[2], tuples[3]),
                               (t01, tuples[2]), (t01, t23)):
            spe_records.append(packed_hex([*earlier, *later, *combine(later, earlier)]))
        reference = float_recurrence(raw_p[start:start + valid], raw_q[start:start + valid])
        local_errors.extend(eq[i] / 32.0 - reference[i] for i in range(valid))
        serial = sequential(bp, bq)
        topology_differences.extend(eq[i] - serial[i] for i in range(valid))
        if first is None:
            first = bp, bq, ep, eq
    (output / "ssa_vectors.hex").write_text("\n".join(records) + "\n")
    (output / "spe_vectors.hex").write_text("\n".join(spe_records) + "\n")
    for name, values in zip(("inputs_P.hex", "inputs_Q.hex", "golden_prefix_P.hex",
                             "golden_state.hex"), first):
        (output / name).write_text("\n".join(packed_hex([v]) for v in values) + "\n")
    torch.save({"p": p, "q": q}, output / "coefficients.pt")

    def clipping_count(values, scale):
        return sum(not -128 <= round(v * scale) <= 127 for v in values)

    global_float = float_recurrence(raw_p, raw_q)
    global_fixed = sequential(fp, fq)
    global_errors = [h / 32.0 - ref for h, ref in zip(global_fixed, global_float)]
    metadata = dict(result["metadata"])
    metadata.update({
        "width": 8, "shift": 6, "q_fraction": 5,
        "spe_count": len(spe_records), "ssa_count": len(records),
        "sequence_length": len(fp), "valid_elements_last_block": (len(fp) - 1) % 4 + 1,
        "batch_index": batch_index, "channel": channel, "state_index": state_index,
        "block_semantics": "independent local prefixes; zero incoming state",
        "internal_overflow": "wrap", "internal_shift": "arithmetic floor",
        "input_rounding": "nearest ties-to-even, then clip",
        "p_input_clipped": clipping_count(raw_p, 64),
        "q_input_clipped": clipping_count(raw_q, 32),
        "p_range": [min(raw_p), max(raw_p)], "q_range": [min(raw_q), max(raw_q)],
        "local_tree_max_abs_error": max(map(abs, local_errors)),
        "local_tree_rmse": math.sqrt(sum(e * e for e in local_errors) / len(local_errors)),
        "local_tree_vs_serial_mismatch_count": sum(e != 0 for e in topology_differences),
        "global_serial_max_abs_error": max(map(abs, global_errors)),
        "accuracy_note": "Errors compare quantized states to recurrence over extracted FP32 coefficients, not end-to-end model accuracy.",
    })
    (output / "manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, help="Local checkpoint directory or Hugging Face ID")
    parser.add_argument("--tokenizer", help="Optional tokenizer directory/ID if not saved with the model")
    parser.add_argument("--prompt", default="What is machine learning?")
    parser.add_argument("--max-length", type=int, default=64, help="Truncation limit, NOT a claimed actual length")
    parser.add_argument("--layer", type=int, default=0)
    parser.add_argument("--channel", type=int, default=0)
    parser.add_argument("--state", type=int, default=0)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--output", type=Path, default=Path("artifacts/model_trace"))
    args = parser.parse_args()
    if args.max_length < 1:
        parser.error("--max-length must be positive")
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer or args.model)
    model = MambaForCausalLM.from_pretrained(args.model, torch_dtype=torch.float32).to(args.device)
    tokens = tokenizer(args.prompt, return_tensors="pt", truncation=True,
                       max_length=args.max_length).to(args.device)
    result = extract_coefficients(model, tokens["input_ids"], layer_index=args.layer,
                                  attention_mask=tokens.get("attention_mask"))
    result["metadata"]["model"] = args.model
    metadata = export_trace(result, args.output, channel=args.channel, state_index=args.state)
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()