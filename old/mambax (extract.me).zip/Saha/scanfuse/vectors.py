"""Generate deterministic packed records consumed directly by the RTL tests."""

import argparse
import json
from pathlib import Path
import random

from .fixedpoint import DEFAULT, Format, combine, packed_hex, ssa4


def generate(output: Path, *, seed: int = 247, random_cases: int = 2000,
             exhaustive_products: bool = True, fmt: Format = DEFAULT) -> dict:
    if random_cases < 0:
        raise ValueError("random_cases must be nonnegative")
    if exhaustive_products and fmt.width > 8:
        raise ValueError("exhaustive sweep is limited to widths <= 8")
    output.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    edge = sorted({fmt.minimum, fmt.minimum + 1, -1, 0, 1,
                   (1 << fmt.shift) - 1, 1 << fmt.shift, fmt.maximum})
    spe_count = 0
    with (output / "spe_vectors.hex").open("w") as f:
        def write_spe(pi, qi, pj, qj):
            nonlocal spe_count
            po, qo = combine((pj, qj), (pi, qi), fmt)
            f.write(packed_hex([pi, qi, pj, qj, po, qo], fmt) + "\n")
            spe_count += 1

        for pi in edge:
            for qi in edge:
                for pj in edge:
                    for qj in edge:
                        write_spe(pi, qi, pj, qj)
        if exhaustive_products:
            # Every W-bit signed pair reaches BOTH multipliers. The full four-
            # operand Cartesian product is not claimed to be exhaustive.
            for pj in range(fmt.minimum, fmt.maximum + 1):
                for operand in range(fmt.minimum, fmt.maximum + 1):
                    write_spe(operand, operand, pj, rng.choice(edge))
        for _ in range(random_cases):
            write_spe(*(rng.randint(fmt.minimum, fmt.maximum) for _ in range(4)))

    one = 1 << fmt.shift
    blocks = [
        ([0] * 4, [0] * 4),
        ([one] * 4, [1, 2, 3, 4]),
        ([one] * 4, [fmt.maximum] * 4),
        ([one] * 4, [fmt.minimum] * 4),
        ([fmt.minimum] * 4, [fmt.minimum, fmt.maximum, -1, 1]),
        ([0] * 4, [fmt.minimum, fmt.maximum, -1, 1]),
    ]
    if fmt == DEFAULT:
        blocks.append(([63, 14, 39, 38], [-9, 5, -3, 2]))
    for i in range(random_cases):
        # Alternate full signed stress and decay-like P in [0, 1].
        p = [rng.randint(fmt.minimum, fmt.maximum) if i % 2 else
             rng.randint(0, one) for _ in range(4)]
        q = [rng.randint(fmt.minimum, fmt.maximum) for _ in range(4)]
        blocks.append((p, q))
    with (output / "ssa_vectors.hex").open("w") as f:
        for p, q in blocks:
            expected = ssa4(p, q, fmt)
            f.write(packed_hex(p + q + [t[0] for t in expected] +
                               [t[1] for t in expected], fmt) + "\n")
    metadata = {
        "seed": seed, "width": fmt.width, "shift": fmt.shift,
        "q_fraction": fmt.q_fraction, "spe_count": spe_count,
        "ssa_count": len(blocks), "exhaustive_multiplier_pairs": exhaustive_products,
        "spe_record_msb_first": "pi qi pj qj p_out q_out",
        "ssa_record_msb_first": "p[0:4] q[0:4] prefix_p[0:4] prefix_q[0:4]",
    }
    (output / "manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("build/vectors"))
    parser.add_argument("--seed", type=int, default=247)
    parser.add_argument("--random-cases", type=int, default=2000)
    args = parser.parse_args()
    print(json.dumps(generate(args.output, seed=args.seed,
                              random_cases=args.random_cases), indent=2))


if __name__ == "__main__":
    main()