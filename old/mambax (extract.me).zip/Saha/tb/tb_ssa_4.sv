`timescale 1ns / 1ps

module tb_ssa_4;
    parameter integer DATA_WIDTH = 8;
    parameter integer SHIFT_VAL = 6;
    localparam integer W = DATA_WIDTH;
    localparam integer MAX_VECTORS = 200000;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 1;
    reg clk_en = 0;
    reg in_valid = 0;
    reg signed [W-1:0] p0 = 0, p1 = 0, p2 = 0, p3 = 0;
    reg signed [W-1:0] q0 = 0, q1 = 0, q2 = 0, q3 = 0;
    wire signed [W-1:0] s0, s1, s2, s3, pp0, pp1, pp2, pp3;
    wire out_valid;
    wire [8*W-1:0] observed = {pp0,pp1,pp2,pp3,s0,s1,s2,s3};
    reg [16*W-1:0] vectors [0:MAX_VECTORS-1];
    reg [16*W-1:0] record;
    reg [8*W-1:0] stage0, stage1;
    reg valid0, valid1;
    reg [8*W:0] held;
    integer count, index, cycle, checked, canceled, stalls, bubbles, resets;
    integer pass, reset_mode;
    string filename;

    ssa_4 #(.DATA_WIDTH(W), .SHIFT_VAL(SHIFT_VAL)) dut (
        .clk(clk), .rst_n(rst_n), .clk_en(clk_en), .in_valid(in_valid),
        .p0(p0), .p1(p1), .p2(p2), .p3(p3),
        .q0(q0), .q1(q1), .q2(q2), .q3(q3),
        .out_valid(out_valid), .state0(s0), .state1(s1), .state2(s2), .state3(s3),
        .prefix_p0(pp0), .prefix_p1(pp1), .prefix_p2(pp2), .prefix_p3(pp3)
    );

    initial begin
        if (!$value$plusargs("VECTORS=%s", filename)) $fatal(1, "Missing VECTORS");
        if (!$value$plusargs("COUNT=%d", count)) $fatal(1, "Missing COUNT");
        if (count < 1 || count > MAX_VECTORS) $fatal(1, "Invalid vector count");
        $readmemh(filename, vectors, 0, count-1);
        // Pass 0 checks EVERY vector under uninterrupted back-to-back traffic.
        // Pass 1 checks stalls/bubbles. Pass 2 also cancels in-flight work.
        for (pass = 0; pass < 3; pass = pass + 1) begin
            index = 0;
            cycle = 0;
            checked = 0;
            canceled = 0;
            stalls = 0;
            bubbles = 0;
            resets = 0;
            stage0 = 0;
            stage1 = 0;
            valid0 = 0;
            valid1 = 0;
            // Between passes assertion occurs away from clock edges.
            #2 rst_n = 0;
            #1;
            if ({out_valid,observed} !== 0) $fatal(1, "SSA asynchronous reset failed");
            while (index < count || valid0 || valid1) begin
                @(negedge clk);
                held = {out_valid, observed};
                cycle = cycle + 1;
                reset_mode = pass == 2 && cycle % 113 == 0;
                rst_n = !reset_mode;
                clk_en = pass == 0 || !(cycle % 17 == 0 || cycle % 17 == 1 || cycle % 17 == 2);
                in_valid = index < count && (pass == 0 || cycle % 11 != 0);
                record = index < count ? vectors[index] : 0;
                {p0,p1,p2,p3,q0,q1,q2,q3} = record[16*W-1:8*W];
                if (!rst_n) begin
                    resets = resets + 1;
                    #1;
                    if ({out_valid,observed} !== 0) $fatal(1, "SSA reset failed mid-stream");
                end
                @(posedge clk);
                if (!rst_n) begin
                    // stage1 was already observed on its previous enabled edge.
                    // stage0 is the only accepted, not-yet-checked transaction.
                    if (valid0) canceled = canceled + 1;
                    stage0 = 0;
                    stage1 = 0;
                    valid0 = 0;
                    valid1 = 0;
                end else if (clk_en) begin
                    stage1 = stage0;
                    valid1 = valid0;
                    stage0 = record[8*W-1:0];
                    valid0 = in_valid;
                    if (in_valid) index = index + 1;
                    else bubbles = bubbles + 1;
                end else stalls = stalls + 1;
                #1;
                if (out_valid !== valid1) $fatal(1, "SSA valid mismatch pass %0d cycle %0d", pass, cycle);
                if (rst_n && !clk_en && {out_valid,observed} !== held)
                    $fatal(1, "SSA changed during stall cycle %0d", cycle);
                if (rst_n && clk_en && valid1) begin
                    if (observed !== stage1)
                        $fatal(1, "SSA mismatch pass %0d cycle %0d got %h expected %h", pass, cycle, observed, stage1);
                    checked = checked + 1;
                end
                if (cycle > count*10 + 100) $fatal(1, "SSA watchdog expired");
            end
            if (checked + canceled != count) $fatal(1, "SSA transaction accounting failed");
            $display("PASS ssa_4 W=%0d SHIFT=%0d pass=%0d checked=%0d canceled=%0d cycles=%0d stalls=%0d bubbles=%0d resets=%0d",
                     W, SHIFT_VAL, pass, checked, canceled, cycle, stalls, bubbles, resets);
        end
        $finish;
    end
endmodule