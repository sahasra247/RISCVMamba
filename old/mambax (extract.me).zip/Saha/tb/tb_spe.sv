`timescale 1ns / 1ps

module tb_spe;
    parameter integer DATA_WIDTH = 8;
    parameter integer SHIFT_VAL = 6;
    localparam integer W = DATA_WIDTH;
    localparam integer MAX_VECTORS = 200000;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 1;
    reg clk_en = 0;
    reg in_valid = 0;
    reg signed [W-1:0] p_n = 0, q_n = 0, p_next = 0, q_next = 0;
    wire signed [W-1:0] p_out, q_out;
    wire out_valid;
    reg [6*W-1:0] vectors [0:MAX_VECTORS-1];
    reg [6*W-1:0] record;
    reg [2*W-1:0] expected;
    reg [2*W:0] held;
    reg expected_valid;
    integer count, index, cycle, checked, stalls, bubbles, resets;
    string filename;

    spe #(.DATA_WIDTH(W), .SHIFT_VAL(SHIFT_VAL)) dut (
        .clk(clk), .rst_n(rst_n), .clk_en(clk_en), .in_valid(in_valid),
        .p_n(p_n), .q_n(q_n), .p_next(p_next), .q_next(q_next),
        .out_valid(out_valid), .p_out(p_out), .q_out(q_out)
    );

    initial begin
        if (!$value$plusargs("VECTORS=%s", filename)) $fatal(1, "Missing VECTORS");
        if (!$value$plusargs("COUNT=%d", count)) $fatal(1, "Missing COUNT");
        if (count < 1 || count > MAX_VECTORS) $fatal(1, "Invalid vector count");
        $readmemh(filename, vectors, 0, count-1);
        index = 0;
        cycle = 0;
        checked = 0;
        stalls = 0;
        bubbles = 0;
        resets = 0;
        expected = 0;
        expected_valid = 0;
        // Assert asynchronously, away from a rising clock edge.
        #2 rst_n = 0;
        #1;
        if ({out_valid,p_out,q_out} !== 0) $fatal(1, "SPE asynchronous reset failed");
        while (index < count || expected_valid) begin
            @(negedge clk);
            held = {out_valid, p_out, q_out};
            cycle = cycle + 1;
            // Deterministic mixed traffic: long consecutive runs, bubbles,
            // multi-cycle stalls, and reset while transactions are active.
            rst_n = (cycle % 251 != 0);
            clk_en = !(cycle % 19 == 0 || cycle % 19 == 1 || cycle % 19 == 2);
            in_valid = index < count && cycle % 13 != 0;
            record = index < count ? vectors[index] : 0;
            {p_n, q_n, p_next, q_next} = record[6*W-1:2*W];
            if (!rst_n) begin
                resets = resets + 1;
                #1;
                if ({out_valid,p_out,q_out} !== 0) $fatal(1, "SPE reset failed mid-stream");
            end
            @(posedge clk);
            if (!rst_n) begin
                expected = 0;
                expected_valid = 0;
            end else if (clk_en) begin
                expected_valid = in_valid;
                expected = record[2*W-1:0];
                if (in_valid) index = index + 1;
                else bubbles = bubbles + 1;
            end else stalls = stalls + 1;
            #1;
            if (out_valid !== expected_valid) $fatal(1, "SPE valid mismatch cycle %0d", cycle);
            if (rst_n && !clk_en && {out_valid,p_out,q_out} !== held)
                $fatal(1, "SPE changed during stall cycle %0d", cycle);
            if (rst_n && clk_en && expected_valid) begin
                if ({p_out,q_out} !== expected)
                    $fatal(1, "SPE mismatch vector %0d got %h expected %h", index-1, {p_out,q_out}, expected);
                checked = checked + 1;
            end
            if (cycle > count*10 + 100) $fatal(1, "SPE watchdog expired");
        end
        if (checked != count) $fatal(1, "Not all SPE vectors checked");
        $display("PASS spe W=%0d SHIFT=%0d checked=%0d cycles=%0d stalls=%0d bubbles=%0d resets=%0d",
                 W, SHIFT_VAL, checked, cycle, stalls, bubbles, resets);
        $finish;
    end
endmodule